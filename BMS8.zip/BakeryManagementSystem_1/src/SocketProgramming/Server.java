/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SocketProgramming;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;

public class Server {

    public static void main(String[] args) throws IOException {
        Socket socket;
        InputStreamReader inputStreamReader;
        OutputStreamWriter outputStreamWriter;
        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;
        ServerSocket serversocket;
        serversocket = new ServerSocket(4500);
        while (true) {
            try {
                socket = serversocket.accept();
                inputStreamReader = new InputStreamReader(socket.getInputStream());
                outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());
                bufferedReader = new BufferedReader(inputStreamReader);
                bufferedWriter = new BufferedWriter(outputStreamWriter);
                while (true) {
                    String msgFromClient = bufferedReader.readLine();
                    System.out.println("Client: " + msgFromClient);
                    
                         if(msgFromClient.equalsIgnoreCase("What are your delivery charges?"))
                        {
                        
                    bufferedWriter.write("Delivery Charges are Rs.200 for areas that are not within 2km radius");
                    bufferedWriter.newLine();
                    bufferedWriter.flush();
                    String a="Delivery Charges are Rs.200 for areas that are not within 2km radius";
                       JOptionPane.showMessageDialog( null,a);
                        }
                         if(msgFromClient.equalsIgnoreCase("What is your opening and closing time?"))
                        {
                       
                         bufferedWriter.write("we provide 24/7 service");
                    bufferedWriter.newLine();
                    bufferedWriter.flush();
                     String b="we provide 24/7 service";
                       JOptionPane.showMessageDialog( null,b);
                        }
                    
                         if(msgFromClient.equalsIgnoreCase("What is your Help Line Number?"))
                        {
                        String a="You can contact us on whatsapp Number=0300-0000001";
                       JOptionPane.showMessageDialog( null,a);
                         bufferedWriter.write("You can contact us on whatsapp Number=0300-0000001");
                    bufferedWriter.newLine();
                    bufferedWriter.flush();
                    }
                         if(msgFromClient.equalsIgnoreCase("How to place order?"))
                    
                    {
                        String a="Look for Place Order button on homepage";
                       JOptionPane.showMessageDialog( null,a);
                         bufferedWriter.write("Look for Place Order button on homepage");
                    bufferedWriter.newLine();
                    bufferedWriter.flush();
                    }
                   
                     if(msgFromClient.equalsIgnoreCase("0"))
                        break;
                    }
                
            
        
                socket.close();
                inputStreamReader.close();
                outputStreamWriter.close();
                bufferedReader.close();
                bufferedWriter.close();
            }
    
        catch (IOException e) {
                e.printStackTrace();
            }
    }
        }
    }

