/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author clicks
 */
public class DbOperations {
    public static void setDataOrDelete(String query,String msg)
    {
        try{
            Connection conn = DBConnection.getCon();
            Statement stm = conn.createStatement();
            stm.executeUpdate(query);
            if(!msg.equals(""))
            {
                JOptionPane.showMessageDialog(null, msg);
            }
                
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e, "Message",JOptionPane.ERROR_MESSAGE);
        }
    }
    public static ResultSet getData(String query)
    {
        try
        {
            Connection conn = DBConnection.getCon();
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery(query);
            return rs;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e, "Message",JOptionPane.ERROR_MESSAGE);
            return null;

        }
    }
            
}
