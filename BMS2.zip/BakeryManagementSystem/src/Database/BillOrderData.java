/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import Classes.OrderBill;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author clicks
 */
public class BillOrderData {
    public static String getID()
    {
        int id = 1;
        try
        {
            ResultSet r = DbOperations.getData("select max(id) from order_bill");
            if(r.next())
            {
                id = r.getInt(1);
                id = id+1;
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        return String.valueOf(id);    }
    
    public static void save(OrderBill b)
    {
        String query = "insert into order_bill values('"+b.getId()+"','"+b.getName()+"','"+b.getMobileNo()+"','"+b.getEmail()+"','"+b.getDate()+"','"+b.getTotal()+"','"+b.getCreatedBy()+"')";
        DbOperations.setDataOrDelete(query, "Bill Details Added Successfully");
            
    }}
