/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import Database.userDao;
import java.util.ArrayList;
//import java.util.List;
//import java.util.ArrayList;
import Classes.User;
//import Classes.userDao;



/**
 *
 * @author clicks
 */
public class newItems {
    private ArrayList <User> users = userDao.Records();
    public String ItemName;
    public void notifyExistingUser(String ItemName) {
        for (User user : users) {
            user.update(ItemName);
        }

    }

    public void ProductAdded(String ItemName) {
       this.ItemName = ItemName;
        notifyExistingUser(ItemName);

    }



}
