/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import javax.swing.JOptionPane;

/**
 *
 * @author clicks
 */
public class Tables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try 
        { 
            //String Products = "create table products(id int AUTO_INCREMENT primary key, name varchar(200), category varchar(200), price varchar(200))";
            //tring OrderBill = "create table order_bill(id int primary key, name varchar(200), mobileNumber varchar(25), email varchar(200), date varchar(200), total varchar(25),createdBy varchar(200))";
           // DbOperations.setDataOrDelete(Products, "Product table is created");
             //DbOperations.setDataOrDelete(OrderBill, "OrderBill table is created");
            String userTable = "create table user(id int AUTO_INCREMENT primary key,name varchar(200),email varchar(200),mobileNumber varchar(10),address varchar(200),password varchar(200),securityQuestion varchar(200),answer varchar(200),status varchar(20), UNIQUE (email))";
              String adminDetails = "insert into user(name,email,mobileNumber,password, address,SecurityQuestion,answer,status)values('Admin','admin@gmail.com','1234567890','rawalpindi','admin','what is your pet name','ABC','true')";
          //String user = "create table user (id int AUTO_INCREMENT primary key,name varchar(200),email varchar(200),mobileNumber varchar(10),password varchar(200), status varchar(20),UNIQUE(email))"; //query
            //DbOperations.setDataOrDelete(userTable, "User Table Created");
            DbOperations.setDataOrDelete(userTable, "Table Created Successfully");
            DbOperations.setDataOrDelete(adminDetails, "admin Details added");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
