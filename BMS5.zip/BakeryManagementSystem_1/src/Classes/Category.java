/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author clicks
 */
public class Category {
    private int id;
    private String bakery_category;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBakery_category() {
        return bakery_category;
    }

    public void setBakery_category(String bakery_category) {
        this.bakery_category = bakery_category;
    }
    
}
