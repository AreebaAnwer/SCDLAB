/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import javax.swing.JOptionPane;

/**
 *
 * @author clicks
 */
public class Tables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try 
        { 
            String Products = "create table products(id int AUTO_INCREMENT primary key, name varchar(200), category varchar(200), price varchar(200))";
            DbOperations.setDataOrDelete(Products, "Product table is created");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
