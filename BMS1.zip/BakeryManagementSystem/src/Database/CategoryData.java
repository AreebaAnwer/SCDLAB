/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import Classes.Category;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.*;

/**
 *
 * @author clicks
 */
public class CategoryData {
    public static void save(Category category)
    {
    String query = "insert into category (name) values('"+category.getBakery_category()+"')";
    DbOperations.setDataOrDelete(query,"Category is Successfully added to Bakery");
    }
    public static ArrayList<Category> getAllRedords()
    {
        ArrayList<Category> arrayList = new ArrayList<>();
        try{
            ResultSet rs = DbOperations.getData("select * from category");
            while(rs.next()){
                Category category = new Category();
                category.setId(rs.getInt("id"));
                category.setBakery_category(rs.getString("name"));
                arrayList.add(category);
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            
    }
        return arrayList;
            }
    public static void delete(String id)
    {
        String query = "delete from category where id = '"+id+"'";
        DbOperations.setDataOrDelete(query,"Category is Successfully deleted from Bakery");
    }
}
