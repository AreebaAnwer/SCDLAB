/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;
import Classes.Product;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author clicks
 */
public class ProductData {
    public static void save(Product prod)
    {
    String query = "insert into products (name,category,price) values('"+prod.getCategory()+"','"+prod.getName()+"','"+prod.getPrice()+"')";
    DbOperations.setDataOrDelete(query,"Product is Successfully added to Bakery");
    }
    public static ArrayList<Product> getAllRecords()
    {
        ArrayList <Product> a = new ArrayList<>();
        try 
        {
            ResultSet r = DbOperations.getData("select * from products");
            while (r.next())
            {
                Product p = new Product();
                p.setId(r.getInt("id"));
                p.setName(r.getString("name"));
                p.setCategory(r.getString("category"));
                p.setPrice(r.getString("price"));
                a.add(p);
            }
        }
        catch(Exception e)
        { 
            JOptionPane.showMessageDialog(null, e);
        }
        
        return a;
    }
    
    public static void update(Product p)
    { 
        
        String q1 = "update products set name ='" + p.getName()+"' , category = '"+ p.getCategory()+" ',  price = ' "+p.getPrice()+" '  where id = ' "+p.getId()+"'";
        DbOperations.setDataOrDelete(q1, "Product Updated Successfully");
    }
    public static void delete (String id)     
    {
        String query = "delete from products where id = '"+id+"'";
        DbOperations.setDataOrDelete(query, "Product Deleted Successfuly");
    }
}
